NaoMiniPet v0.6 Android project payload for Codemagic.
