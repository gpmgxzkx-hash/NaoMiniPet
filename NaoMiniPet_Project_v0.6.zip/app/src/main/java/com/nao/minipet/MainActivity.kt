package com.nao.minipet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val overlayRequestCode = 9001
    private lateinit var prefs: PetPrefs
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PetPrefs(this)

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(36), dp(24), dp(28))
        }
        val scroll = ScrollView(this).apply { addView(root) }

        root.addView(TextView(this).apply {
            text = "ナオのミニペット"
            textSize = 30f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "歩く・揺れる・反応する、ナオ専用ナビゲーター"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(18))
        })

        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.argb(18, 0, 0, 0))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        root.addView(Button(this).apply {
            text = "ミニペットを起動"
            setOnClickListener { ensurePermissionAndStart() }
        }, fullWidth())
        root.addView(Button(this).apply {
            text = "ミニペットを終了"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayPetService::class.java)) }
        }, fullWidth())

        addSection(root, "キャラ設定")
        addSeek(root, "大きさ", 90, 240, prefs.sizeDp) { prefs.sizeDp = it; refreshPet() }
        addSeek(root, "透明度", 35, 100, prefs.opacityPercent) { prefs.opacityPercent = it; refreshPet() }
        addSeek(root, "移動スピード", 10, 100, prefs.speed) { prefs.speed = it; refreshPet() }

        root.addView(toggle("自動で画面内を歩く", prefs.autoRoam) { prefs.autoRoam = it; refreshPet() }, fullWidth())
        root.addView(toggle("待機中もゆらゆら動く", prefs.idleMotion) { prefs.idleMotion = it; refreshPet() }, fullWidth())
        root.addView(toggle("ドラッグ後に画面端へ寄る", prefs.edgeSnap) { prefs.edgeSnap = it; refreshPet() }, fullWidth())
        root.addView(toggle("タップ時にセリフを表示", prefs.speech) { prefs.speech = it; refreshPet() }, fullWidth())

        addSection(root, "入っているモーション")
        root.addView(TextView(this).apply {
            text = "• 待機：呼吸＋小さな揺れ\n• 歩行：上下に弾みながら画面内を移動\n• 向き：進行方向に合わせて左右反転\n• タップ：ぴょこっと跳ねてリアクション\n• 長押し：その場で60秒お休み\n• ドラッグ：好きな場所へ移動\n• 低バッテリー・朝・深夜で専用セリフ"
            textSize = 16f
            setPadding(dp(6), dp(4), dp(6), dp(16))
        }, fullWidth())

        setContentView(scroll)
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
    }

    private fun toggle(label: String, initial: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = label
        isChecked = initial
        setPadding(0, dp(10), 0, dp(10))
        setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }

    private fun addSection(root: LinearLayout, title: String) {
        root.addView(TextView(this).apply {
            text = title
            textSize = 21f
            setPadding(0, dp(22), 0, dp(8))
        }, fullWidth())
    }

    private fun addSeek(root: LinearLayout, label: String, min: Int, max: Int, initial: Int, onChange: (Int) -> Unit) {
        val valueLabel = TextView(this).apply { textSize = 16f }
        val update: (Int) -> Unit = { v -> valueLabel.text = "$label：$v" }
        update(initial)
        root.addView(valueLabel, fullWidth())
        root.addView(SeekBar(this).apply {
            this.max = max - min
            progress = initial - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = progress + min
                    update(v)
                    if (fromUser) onChange(v)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }, fullWidth())
    }

    private fun ensurePermissionAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequestCode)
            return
        }
        val intent = Intent(this, OverlayPetService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "ミニペットを呼んだよ", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun refreshPet() {
        if (!Settings.canDrawOverlays(this)) return
        val intent = Intent(this, OverlayPetService::class.java).setAction(OverlayPetService.ACTION_REFRESH)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun updateStatus() {
        status.text = if (Settings.canDrawOverlays(this)) "✓ 『他のアプリの上に表示』は許可済み" else "！ 初回だけ『他のアプリの上に表示』を許可してね"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequestCode && Settings.canDrawOverlays(this)) ensurePermissionAndStart()
    }

    private fun fullWidth() = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
