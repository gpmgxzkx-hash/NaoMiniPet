package com.nao.minipet

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

class OverlayPetService : Service() {
    companion object {
        const val ACTION_REFRESH = "com.nao.minipet.REFRESH"
        const val ACTION_STOP = "com.nao.minipet.STOP"
    }

    private lateinit var wm: WindowManager
    private lateinit var pet: ImageView
    private lateinit var petParams: WindowManager.LayoutParams
    private lateinit var prefs: PetPrefs
    private val handler = Handler(Looper.getMainLooper())

    private var dragging = false
    private var moving = false
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0
    private var pausedUntil = 0L
    private var lastBubble: View? = null
    private var lastInteractionAt = System.currentTimeMillis()

    private val wander = object : Runnable {
        override fun run() {
            if (::pet.isInitialized && prefs.autoRoam && !dragging && !moving && System.currentTimeMillis() > pausedUntil) {
                roam()
            }
            handler.postDelayed(this, roamDelayMs())
        }
    }

    private val idleTick = object : Runnable {
        override fun run() {
            if (::pet.isInitialized && prefs.idleMotion && !dragging && !moving && System.currentTimeMillis() > pausedUntil) {
                idleGesture()
            }
            handler.postDelayed(this, Random.nextLong(2600L, 5200L))
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = PetPrefs(this)
        startAsForeground()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createPet()
        handler.postDelayed(wander, 1600)
        handler.postDelayed(idleTick, 2400)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REFRESH -> if (::pet.isInitialized) applyPreferences()
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "mini_pet"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "ミニペット", NotificationManager.IMPORTANCE_LOW).apply {
                description = "ナオの画面でミニペットを表示するための通知"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, OverlayPetService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        val notification = builder
            .setContentTitle("ミニペットがお供中")
            .setContentText("歩く・揺れる・タップで反応します")
            .setSmallIcon(android.R.drawable.star_on)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "終了", stop).build())
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(101, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(101, notification)
        }
    }

    private fun createPet() {
        pet = ImageView(this).apply {
            setImageResource(R.drawable.pet)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            elevation = dp(16).toFloat()
            isClickable = true
            isLongClickable = true
        }

        val width = dp(prefs.sizeDp)
        val height = (width * 1.27f).toInt()
        petParams = WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(220)
        }

        pet.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    moving = false
                    lastInteractionAt = System.currentTimeMillis()
                    downRawX = e.rawX
                    downRawY = e.rawY
                    startX = petParams.x
                    startY = petParams.y
                    pet.animate().cancel()
                    pet.animate().scaleX(signedScale(1.05f)).scaleY(1.05f).setDuration(90).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downRawX).toInt()
                    val dy = (e.rawY - downRawY).toInt()
                    if (abs(dx) + abs(dy) > dp(8)) dragging = true
                    if (dragging) {
                        val pos = clampPosition(startX + dx, startY + dy)
                        petParams.x = pos.first
                        petParams.y = pos.second
                        safeUpdate()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    pet.animate().scaleX(signedScale(1f)).scaleY(1f).rotation(0f).translationY(0f).setDuration(100).start()
                    if (!dragging) react() else if (prefs.edgeSnap) snapToNearestEdge()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    pet.animate().scaleX(signedScale(1f)).scaleY(1f).rotation(0f).translationY(0f).setDuration(100).start()
                    true
                }
                else -> false
            }
        }

        pet.setOnLongClickListener {
            lastInteractionAt = System.currentTimeMillis()
            pausedUntil = System.currentTimeMillis() + 60_000
            moving = false
            pet.animate().cancel()
            pet.animate().rotation(8f).translationY(dp(10).toFloat()).scaleY(0.94f).setDuration(220).start()
            showSpeech("……少しだけ、ここで休むわ。")
            true
        }

        wm.addView(pet, petParams)
        applyPreferences()
        breathe()
    }

    private fun signedScale(magnitude: Float): Float = if (pet.scaleX < 0f) -magnitude else magnitude

    private fun applyPreferences() {
        pet.alpha = prefs.opacityPercent / 100f
        val width = dp(prefs.sizeDp)
        petParams.width = width
        petParams.height = (width * 1.27f).toInt()
        val clamped = clampPosition(petParams.x, petParams.y)
        petParams.x = clamped.first
        petParams.y = clamped.second
        safeUpdate()
    }

    private fun breathe() {
        if (!::pet.isInitialized) return
        if (prefs.idleMotion && !moving && !dragging && System.currentTimeMillis() > pausedUntil) {
            pet.animate().translationY(-dp(3).toFloat()).setDuration(900)
                .setInterpolator(AccelerateDecelerateInterpolator())
                .withEndAction {
                    if (!::pet.isInitialized) return@withEndAction
                    pet.animate().translationY(0f).setDuration(900)
                        .withEndAction { handler.postDelayed({ breathe() }, 150) }.start()
                }.start()
        } else {
            handler.postDelayed({ breathe() }, 600)
        }
    }

    private fun idleGesture() {
        val face = pet.scaleX.signPreservedMagnitude()
        val choice = Random.nextInt(3)
        when (choice) {
            0 -> pet.animate().scaleX(face * 0.98f).scaleY(0.93f).setDuration(90).withEndAction {
                pet.animate().scaleX(face).scaleY(1f).setDuration(120).start()
            }.start()
            1 -> pet.animate().rotation(if (pet.scaleX < 0f) -4f else 4f).setDuration(180).withEndAction {
                pet.animate().rotation(0f).setDuration(180).start()
            }.start()
            else -> pet.animate().translationY(-dp(7).toFloat()).setDuration(160).withEndAction {
                pet.animate().translationY(0f).setDuration(180).start()
            }.start()
        }
    }

    private fun Float.signPreservedMagnitude(): Float = if (this < 0f) -1f else 1f

    private fun roam() {
        val bounds = screenBounds()
        if (bounds.first <= 0 || bounds.second <= dp(90)) return
        val targetX = Random.nextInt(0, bounds.first + 1)
        val targetY = Random.nextInt(dp(72), bounds.second + 1)
        val startPX = petParams.x
        val startPY = petParams.y
        val dx = targetX - startPX
        pet.scaleX = if (dx < 0) -1f else 1f

        val distance = abs(dx) + abs(targetY - startPY)
        val baseFrames = (distance / dp(8)).coerceIn(28, 100)
        val speedFactor = (110 - prefs.speed).coerceIn(10, 100) / 55f
        val frames = (baseFrames * speedFactor).toInt().coerceIn(18, 150)
        var frame = 0
        moving = true

        val mover = object : Runnable {
            override fun run() {
                if (!::pet.isInitialized || dragging || frame > frames || !prefs.autoRoam) {
                    moving = false
                    pet.rotation = 0f
                    pet.translationY = 0f
                    return
                }
                val t = frame.toFloat() / frames
                val eased = t * t * (3f - 2f * t)
                petParams.x = (startPX + (targetX - startPX) * eased).toInt()
                petParams.y = (startPY + (targetY - startPY) * eased).toInt()

                // Walking illusion: tiny hop + body sway while the overlay moves.
                val phase = frame * 0.72f
                pet.translationY = (-abs(sin(phase)) * dp(5)).toFloat()
                pet.rotation = (sin(phase) * 2.8f)
                safeUpdate()
                frame++
                if (frame <= frames) handler.postDelayed(this, 24) else {
                    moving = false
                    pet.animate().rotation(0f).translationY(0f).setDuration(120).start()
                }
            }
        }
        handler.post(mover)
    }

    private fun snapToNearestEdge() {
        val maxX = screenBounds().first
        val targetX = if (petParams.x < maxX / 2) 0 else maxX
        val start = petParams.x
        var f = 0
        val total = 12
        val snap = object : Runnable {
            override fun run() {
                if (!::pet.isInitialized || dragging) return
                val t = f.toFloat() / total
                petParams.x = (start + (targetX - start) * t).toInt()
                safeUpdate()
                f++
                if (f <= total) handler.postDelayed(this, 16)
            }
        }
        handler.post(snap)
    }

    private fun react() {
        lastInteractionAt = System.currentTimeMillis()
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val battery = batteryPercent()
        val contextual = when {
            battery in 0..20 -> "バッテリー少ないわよ。充電した方がいいんじゃない？"
            hour in 5..10 -> "おはよ、ナオ。今日もちゃんと起きたのね。"
            hour >= 23 || hour <= 4 -> "もう遅い時間よ。無理しすぎないでね。"
            else -> null
        }
        val lines = listOfNotNull(
            contextual,
            "ナオ、呼んだ？",
            "……別に、暇だっただけ。",
            "ちゃんと休憩もしなさいよ？",
            "よし。次は何する？",
            "……見てるから。頑張りなさい。",
            "そこ、タップしすぎ。……まあ嫌じゃないけど。"
        )
        pet.animate().cancel()
        val dir = if (pet.scaleX < 0f) -1f else 1f
        pet.animate().translationY(-dp(12).toFloat()).rotation(7f * dir).setDuration(110).withEndAction {
            pet.animate().translationY(0f).rotation(-4f * dir).setDuration(130).withEndAction {
                pet.animate().rotation(0f).setDuration(90).start()
            }.start()
        }.start()
        if (prefs.speech) showSpeech(lines.random())
    }

    private fun batteryPercent(): Int {
        val intent = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (level >= 0 && scale > 0) (level * 100 / scale) else -1
    }

    private fun showSpeech(text: String) {
        lastBubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        val bubble = TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(0xFF222222.toInt())
            setBackgroundColor(0xEEFFFFFF.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            elevation = dp(18).toFloat()
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (petParams.x - dp(20)).coerceAtLeast(0)
            y = (petParams.y - dp(62)).coerceAtLeast(dp(20))
        }
        lastBubble = bubble
        try { wm.addView(bubble, p) } catch (_: Exception) { return }
        handler.postDelayed({
            if (lastBubble === bubble) lastBubble = null
            try { wm.removeView(bubble) } catch (_: Exception) {}
        }, 2400)
    }

    private fun clampPosition(x: Int, y: Int): Pair<Int, Int> {
        val bounds = screenBounds()
        return x.coerceIn(0, bounds.first) to y.coerceIn(dp(28), bounds.second)
    }

    private fun screenBounds(): Pair<Int, Int> {
        val metrics = resources.displayMetrics
        val maxX = (metrics.widthPixels - petParams.width).coerceAtLeast(0)
        val maxY = (metrics.heightPixels - petParams.height - dp(64)).coerceAtLeast(dp(28))
        return maxX to maxY
    }

    private fun safeUpdate() {
        try { wm.updateViewLayout(pet, petParams) } catch (_: Exception) {}
    }

    private fun roamDelayMs(): Long = (5200L - prefs.speed * 28L).coerceIn(2200L, 5000L)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        lastBubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        if (::pet.isInitialized) try { wm.removeView(pet) } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
