package com.nao.minipet

import android.content.Context

class PetPrefs(context: Context) {
    private val p = context.getSharedPreferences("pet_prefs", Context.MODE_PRIVATE)

    var sizeDp: Int
        get() = p.getInt("size_dp", 150)
        set(value) = p.edit().putInt("size_dp", value.coerceIn(90, 240)).apply()

    var opacityPercent: Int
        get() = p.getInt("opacity", 98)
        set(value) = p.edit().putInt("opacity", value.coerceIn(35, 100)).apply()

    var speed: Int
        get() = p.getInt("speed", 55)
        set(value) = p.edit().putInt("speed", value.coerceIn(10, 100)).apply()

    var autoRoam: Boolean
        get() = p.getBoolean("auto_roam", true)
        set(value) = p.edit().putBoolean("auto_roam", value).apply()

    var speech: Boolean
        get() = p.getBoolean("speech", true)
        set(value) = p.edit().putBoolean("speech", value).apply()

    var idleMotion: Boolean
        get() = p.getBoolean("idle_motion", true)
        set(value) = p.edit().putBoolean("idle_motion", value).apply()

    var edgeSnap: Boolean
        get() = p.getBoolean("edge_snap", false)
        set(value) = p.edit().putBoolean("edge_snap", value).apply()
}
