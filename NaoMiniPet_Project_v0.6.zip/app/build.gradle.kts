plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nao.minipet"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nao.minipet"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.5.0"
    }
}

